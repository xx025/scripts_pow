// ==UserScript==
// @name         shigeshumai
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://220.197.177.18:61235/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=177.18
// @require      file:///E:\github\scripts_pow\shigeshumao\shigeshumao.js
// @grant        none
// ==/UserScript==


